﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace Calculator
{
    public partial class Form1 : Form
    {
        Calculator calculator = new Calculator();
        public Form1()
        {
            InitializeComponent();
        }

        private void button_Click(object sender, EventArgs e)
        {
            calculator.Add((sender as Button).Text);
            this.calculatorInput.Text = calculator.ToString();
        }

        private void eraseBackButton_Click(object sender, EventArgs e)
        {
            calculator.Erase(this.calculatorInput);
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            calculator.Clear(this.calculatorInput);
        }

        private void solveButton_Click(object sender, EventArgs e)
        {
            calculator.Solve();
            this.calculatorInput.Text = calculator.ToString();
        }
        private void changeSign_Click(object sender, EventArgs e)
        {
            if (calculator.Equation.Count != 0)
            {
                if (calculator.Equation[calculator.Equation.Count - 1][0] == '-' && calculator.Equation[calculator.Equation.Count - 1].Length >= 2)
                {
                    calculator.Equation[calculator.Equation.Count - 1] = calculator.Equation[calculator.Equation.Count - 1].Substring(1);
                }
                else if(!calculator.Equation[calculator.Equation.Count - 1].Any(x => calculator.Operators.Contains(x.ToString())))
                {
                    calculator.Equation[calculator.Equation.Count - 1] = calculator.Equation[calculator.Equation.Count - 1].Insert(0, "-");
                }
            }
            this.calculatorInput.Text = calculator.ToString();
        }
    }
}
