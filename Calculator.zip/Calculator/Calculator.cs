﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.AccessControl;
using System.Text;
using System.Windows.Forms;

namespace Calculator
{
    public class Calculator
    {
        public List<string> Equation { get; private set; } = new List<string>();
        public List<string> Operators { get; } = new List<string> {"+", "-", "x", "/", "%", "^"};
        public override string ToString() 
        {
            string result = string.Empty;
            foreach (string str in Equation)
            {
                result += str + " ";
            }
            return result;
        }
        public void Add(string value)
        {
            if (Operators.Contains(value))
            {
                if (Equation.Count == 0)
                {
                    return;
                }
                 
                if (Operators.Any(x => { return x.Equals(Equation[Equation.Count - 1]); }))
                {
                    return;
                }
                Equation.Add(value.ToString());
                return;
            }

            if (Equation.Count != 0 && !Operators.Contains(Equation[Equation.Count - 1]))
            {
                if (value == "." && Equation[Equation.Count - 1].Any(x => x == '.'))
                {
                    return;
                }
                Equation[Equation.Count - 1] += value;
            }
            else if(value != ".")
            {
                Equation.Add(value.ToString());
            }
        }

        public void Erase(TextBox calculatorInput)
        {
            if (Equation.Count == 0)
            {
                return;
            }
            Equation[Equation.Count - 1] = Equation[Equation.Count - 1].Substring(0, Equation[Equation.Count - 1].Length - 1);
            if (Equation[Equation.Count - 1].Length == 0 || Equation[Equation.Count - 1].Length == 1 && Equation[Equation.Count - 1][0] == '-')
            {
                Equation.RemoveAt(Equation.Count - 1);
            }
            calculatorInput.Text = this.ToString();
        }
        public string Solve() // 7 + 3 * 2 / 1 * 3 - 5 
        {
            if (Equation.Count == 0 || Operators.Any(x => x.Equals(Equation[Equation.Count - 1])))
            {
                return "0";
            }
            while(true)
            {
                int index = Equation.FindIndex(x => x == "^");
                if (index != -1)
                {
                    Equation[index] = Math.Pow(Convert.ToDouble(Equation[index - 1]), Convert.ToDouble(Equation[index + 1])).ToString();
                    Equation.RemoveAt(index + 1);
                    Equation.RemoveAt(index - 1);
                    continue;
                }
                index = Equation.FindIndex(x => x == "x" || x == "/" || x == "%");
                if (index != -1)
                {
                    if (Equation[index] == "x")
                    {
                        Equation[index] = (Convert.ToDouble(Equation[index - 1]) * Convert.ToDouble(Equation[index + 1])).ToString();
                    }
                    else if(Equation[index] == "/")
                    {
                        Equation[index] = (Convert.ToDouble(Equation[index - 1]) / Convert.ToDouble(Equation[index + 1])).ToString();
                    }
                    else if (Equation[index] == "%")
                    {
                        Equation[index] = (Convert.ToDouble(Equation[index - 1]) % Convert.ToDouble(Equation[index + 1])).ToString();
                    }
                    Equation.RemoveAt(index + 1);
                    Equation.RemoveAt(index - 1);
                    continue;
                }
                index = Equation.FindIndex(x => x == "+" || x == "-");
                if (index != -1)
                {
                    if (Equation[index] == "+")
                    {
                        Equation[index] = (Convert.ToDouble(Equation[index - 1]) + Convert.ToDouble(Equation[index + 1])).ToString();
                    }
                    else if (Equation[index] == "-")
                    {
                        Equation[index] = (Convert.ToDouble(Equation[index - 1]) - Convert.ToDouble(Equation[index + 1])).ToString();
                    }
                    Equation.RemoveAt(index + 1);
                    Equation.RemoveAt(index - 1);
                    continue;
                }

                break;
            }
            
            return Equation[0];
        }
        public void Clear(TextBox calculatorInput)
        {
            Equation.Clear();
            calculatorInput.Text = this.ToString();
        }
    }
}